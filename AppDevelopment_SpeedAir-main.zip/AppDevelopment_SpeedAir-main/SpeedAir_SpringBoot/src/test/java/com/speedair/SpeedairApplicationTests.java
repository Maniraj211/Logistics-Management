package com.speedair;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpeedairApplicationTests {

	@Test
	void contextLoads() {
	}

}
