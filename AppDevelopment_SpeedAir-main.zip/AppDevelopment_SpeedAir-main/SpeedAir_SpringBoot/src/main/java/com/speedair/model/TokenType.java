package com.speedair.model;

public enum TokenType {
    BEARER
}
