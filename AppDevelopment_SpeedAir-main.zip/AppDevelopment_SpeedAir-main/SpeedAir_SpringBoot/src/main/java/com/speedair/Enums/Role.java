package com.speedair.Enums;

public enum Role {
    user,
    admin
}
